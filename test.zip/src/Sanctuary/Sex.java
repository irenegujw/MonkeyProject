package Sanctuary;

/**
 * gender of monkeys
 */
public enum Sex {
    MALE, FEMALE
}
