package Sanctuary;

/**
 * species of monkeys
 */
public enum Species {
    DRILL, GUEREZA, HOWLER, MANGABEY, SAKI, SPIDER, SQUIRREL, TAMARIN
}
